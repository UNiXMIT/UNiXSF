const installedVersion = chrome.runtime.getManifest().version;
let globalInit = 0;
let navInit = 1;
let initDropDown = 1;
let globalTimeout;
let globalQueue;
let globalQNotify;
let globalQNotifyWeb;
let globalWebhook;
let globalURLS;
let globalDefectURL;
let globalPP;
let globalEDU;
let globalRefEmail;
let globalFdsRefEmail;
let globalSig;
let globalWide;
let iconURL= chrome.runtime.getURL('icons/rocket128.png');
let intervalID;
let qObserver;
let oldCaseArray = [];
let newCaseArray = [];
let caseTable = [];
let configURL = chrome.runtime.getURL('config/config.html');

function initSyncData() {
    chrome.storage.sync.get({
        savedTimeout: 60,
        savedDefect: '',
        savedPP: '',
        savedEDU: '',
        savedQueue: 'NOTIFY',
        savedQNotify: false,
        savedQNotifyWeb: false,
        savedWebhook: '',
        savedRefEmail: '',
        savedFdsRefEmail: '',
        savedSig: '',
        savedURLS: `{"SFExt":"${configURL}"}`,
        savedWide: false
    }, function(result) {
        globalTimeout = result.savedTimeout;
        globalDefectURL = result.savedDefect;
        globalPP = result.savedPP;
        globalEDU = result.savedEDU;
        globalQueue = result.savedQueue;
        globalQNotify = result.savedQNotify;
        globalQNotifyWeb = result.savedQNotifyWeb;
        globalWebhook = result.savedWebhook;
        globalRefEmail = result.savedRefEmail;
        globalFdsRefEmail = result.savedFdsRefEmail;
        globalSig = result.savedSig;
        globalURLS = result.savedURLS;
        globalWide = result.savedWide;
        globalInit = 1;
    });
}

function getSyncData() {
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'sync') {
            chrome.storage.sync.get({
                savedTimeout: 60,
                savedDefect: '',
                savedPP: '',
                savedEDU: '',
                savedQueue: 'NOTIFY',
                savedQNotify: false,
                savedQNotifyWeb: false,
                savedWebhook: '',
                savedRefEmail: '',
                savedFdsRefEmail: '',
                savedSig: '',
                savedURLS: `{"SFExt":"${configURL}"}`,
                savedWide: false
            }, function(result) {
                if (globalTimeout != result.savedTimeout) {
                    globalTimeout = result.savedTimeout;
                    if (intervalID) {
                        clearInterval(intervalID);
                    }
                    queueRefresh();
                }
                globalDefectURL = result.savedDefect;
                globalPP = result.savedPP;
                globalEDU = result.savedEDU;
                if (globalQueue != result.savedQueue) {
                    globalQueue = result.savedQueue;
                    if (qObserver) {
                        qObserver.disconnect();
                    }
                    oldCaseArray = [];
                    newCaseArray = [];
                    document.querySelector('.QMonActive')?.remove();
                    initQMonitor();
                }
                globalQNotify = result.savedQNotify;
                globalQNotifyWeb = result.savedQNotifyWeb;
                globalWebhook = result.savedWebhook;
                globalRefEmail = result.savedRefEmail;
                globalFdsRefEmail = result.savedFdsRefEmail;
                globalSig = result.savedSig;
                if (globalURLS != result.savedURLS) {
                    globalURLS = result.savedURLS;
                    updateCustomURLs();
                }
                globalWide = result.savedWide;
            });
        }
    });
}

function queueRefresh() {
    if (globalTimeout >= 30) {
        let refreshInterval = globalTimeout * 1000;
        intervalID = setInterval(function() {
            let refreshButton = document.querySelector('#split-left').querySelector('button[name="refreshButton"]');
            if (refreshButton) {
                refreshButton.click();
            }
        }, refreshInterval);
    }
}

function mfNav() {
    let observer = new MutationObserver(mutations => {
        let mfButton = document.querySelector('#oneHeader')?.querySelector('ul.slds-global-actions');
        let liDetect = mfButton?.querySelectorAll('li.slds-global-actions__item');
        if ( (mfButton) && (navInit) && (liDetect.length == 7) && (liDetect[2]) && (liDetect[3]) && (liDetect[4]) ) {
            observer.disconnect();
            (async ()=>{
                navInit = 0;
                let removeButton = mfButton.querySelectorAll('li.slds-global-actions__item');
                for (let i = 2; i < 5 ; ++i) {
                    removeButton[i].remove();
                }
                mfDropDown();
                mfSup();
                mfDefect();
                mfDocumentation();
                thirdLineRef();
                fdsRef();
                consRef();
                addReminder();
                mfPP();
                mfEDU();
                customURLs();
            })();
        }
    });
    observer.observe(document.body, {childList: true, subtree: true});
}

function mfDropDown() {
    let mfButton = document.querySelector('#oneHeader').querySelector('ul.slds-global-actions');
    do {
        if (mfButton) {
            let divOuter = document.createElement('div');
            divOuter.classList.add('mfdropdown', 'mfdropmain');
            let button = divOuter.appendChild(document.createElement('button'));
            button.classList.add('dropbtn');
            let i = divOuter.appendChild(document.createElement('i'));
            i.classList.add('fa-solid', 'fa-caret-down', 'fa-lg');
            let divInner = divOuter.appendChild(document.createElement('div'));
            divInner.classList.add('dropdown-content');
            let ul = divInner.appendChild(document.createElement('ul'));
            ul.classList.add('mflist');
            mfButton.insertBefore(divOuter, mfButton.children[3]);
            initDropDown = 0;
        }
    } while (initDropDown);
}

function createMFMenu(liClass, faClass, liText) {
    let ul = document.querySelector('.mflist');
    let li = ul.appendChild(document.createElement('li'));
    li.classList.add(liClass);
    let fa = li.appendChild(document.createElement('i'));
    fa.classList.add('fa-solid', 'fa-xl');
    fa.classList.add(faClass);
    li.appendChild(document.createTextNode(liText));
}

function mfSup() {
    createMFMenu('mfsup', 'fa-headset', 'Support Portal');
    let mfButtonNew = document.querySelector('#oneHeader').querySelector('.mfsup');
    mfButtonNew.addEventListener('click', mfSupEvent, false);
}

function mfSupEvent() {
    window.open('https://my.rocketsoftware.com/RocketCommunity', '_blank');
}

function mfDefect() {
    createMFMenu('mfde', 'fa-code', 'Jira');
    let mfButtonNew = document.querySelector('#oneHeader').querySelector('.mfde');
    mfButtonNew.addEventListener('click', mfDefectEvent, false);
}

function mfDefectEvent() {
    let caseCheck = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab');
    if (caseCheck) {
        let caseURL = document.querySelector('a.tabHeader[aria-selected="true"]').href;
        if (caseURL.includes("/Case")) {
            const parts = caseURL.split('/');
            const caseID = parts[parts.indexOf('Case') + 1];
            let finalURL = globalDefectURL.replace(/\/$/, "") + '/secure/CustomerView.jspa#caseDetail/' + caseID;
            window.open(finalURL, '_blank');
        } else {
            window.open(globalDefectURL.replace(/\/$/, ""), '_blank');
        }
    } else {
        window.open(globalDefectURL.replace(/\/$/, ""), '_blank');
    }
}

function mfDocumentation() {
    createMFMenu('mfdocs', 'fa-book', 'Documentation');
    let mfButtonNew = document.querySelector('#oneHeader').querySelector('.mfdocs');
    mfButtonNew.addEventListener('click', mfDocumentationEvent, false);
}

function mfDocumentationEvent() {
    window.open('https://docs.rocketsoftware.com/', '_blank');
}

function thirdLineRef() {
    createMFMenu('thirdLineRef', 'fa-paper-plane', '3rd Line Referral');
    let mfButtonNew = document.querySelector('#oneHeader').querySelector('.thirdLineRef');
    mfButtonNew.addEventListener('click', thirdLineRefEvent, false);
}

function thirdLineRefEvent() {
    thirdRefEmail();
}

function thirdRefEmail() {
    let caseURL;
    let caseNumber;
    let caseSubject;
    let caseContact;
    let caseContactURL;
    let caseAccount;
    let caseAccountURL;
    let caseSeverity;
    let caseProduct;
    let userQuery;
    let caseCheck = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab');
    if (caseCheck) {
        caseNumber = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Case Number"] [name="outputField"]').innerText;
        caseSubject = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Subject"] [name="outputField"]').innerText;
        caseContact = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Contact Name"] [name="outputField"] a').innerText;
        caseContactURL = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Contact Name"] [name="outputField"] a').href;
        caseAccount = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Account Name"] [name="outputField"] a').innerText;
        caseAccountURL = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Account Name"] [name="outputField"] a').href;
        caseSeverity = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Severity"] [name="outputField"]').innerText;
        caseProduct = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Product"] [name="outputField"] a').innerText;
        caseURL = document.querySelector('a.tabHeader[aria-selected="true"]').href;
    }
    if ((caseNumber) && (caseSubject) && (caseContact) && (caseAccount) && (caseURL) && (caseProduct)) {
        userQuery = {
        "to" : globalRefEmail,
        "subject" : `3rd Line Referral for ${caseContact}@${caseAccount} RE: ${caseNumber} - ${caseSubject}`,
        "body" : `
PRODUCT: ${caseProduct}
CUSTOMER: ${caseContact} - ${caseContactURL}
ACCOUNT: ${caseAccount} - ${caseAccountURL}
SF CASE: ${caseNumber} - ${caseSubject} - ${caseURL}
SEVERITY: ${caseSeverity}

CASE SUMMARY 
• Issue Summary

• Diagnostics Summary

• Hypothesis & Additional Details

• Relevant Case Attachments

`
        };
    } else {
        userQuery = {
        "to" : globalRefEmail,
        "subject" : `3rd Line Referral for [Customer Name]@[Account Name] RE: [SF Case Number] - [SF Case Subject]`,
        "body" : `
PRODUCT: [Product Name]
CUSTOMER: [Customer Name] - [Customer URL]
ACCOUNT: [Account Name] - [Account URL]
SF CASE: [SF Case Number] - [SF Case Subject] - [SF Case URL]
SEVERITY: [Case Severity]

CASE SUMMARY 

• Issue Summary

• Diagnostics Summary

• Hypothesis & Additional Details

• Relevant Case Attachments

`
        };
    }
    let outlookURL = "https://outlook.office.com/mail/deeplink/compose";
    let finalQuery = [];
    Object.entries(userQuery).forEach(([key, value]) => {
        finalQuery.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
    });
    let finalURL = outlookURL + (finalQuery.length ? '?' + finalQuery.join('&') : '');
    window.open(finalURL, '3rd Line Referral', 'width=1600,height=900');
}

function fdsRef() {
    createMFMenu('fdsRef', 'fa-paper-plane', 'FDS Referral');
    let mfButtonNew = document.querySelector('#oneHeader').querySelector('.fdsRef');
    mfButtonNew.addEventListener('click', fdsRefEvent, false);
}

function fdsRefEvent() {
    FDSrefEmail();
}

function FDSrefEmail() {
    let caseURL;
    let caseNumber;
    let caseSubject;
    let caseContact;
    let caseContactURL;
    let caseAccount;
    let caseAccountURL;
    let caseSeverity;
    let caseProduct;
    let userQuery;
    let caseCheck = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab');
    if (caseCheck) {
        caseNumber = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Case Number"] [name="outputField"]').innerText;
        caseSubject = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Subject"] [name="outputField"]').innerText;
        caseContact = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Contact Name"] [name="outputField"] a').innerText;
        caseContactURL = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Contact Name"] [name="outputField"] a').href;
        caseAccount = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Account Name"] [name="outputField"] a').innerText;
        caseAccountURL = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Account Name"] [name="outputField"] a').href;
        caseSeverity = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Severity"] [name="outputField"]').innerText;
        caseProduct = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Product"] [name="outputField"] a').innerText;
        caseURL = document.querySelector('a.tabHeader[aria-selected="true"]').href;
    }
    if ((caseNumber) && (caseSubject) && (caseContact) && (caseAccount) && (caseURL) && (caseProduct)) {
        userQuery = {
        "to" : globalFdsRefEmail,
        "subject" : `FDS Referral for ${caseContact}@${caseAccount} RE: ${caseNumber} - ${caseSubject}`,
        "body" : `
PRODUCT: ${caseProduct}
CUSTOMER: ${caseContact} - ${caseContactURL}
ACCOUNT: ${caseAccount} - ${caseAccountURL}
SF CASE: ${caseNumber} - ${caseSubject} - ${caseURL}
SEVERITY: ${caseSeverity}
FDS INVOLVED: [FDS Name and Version]
FDS ERROR: [Clear description of the issue and steps to reproduce] 
`
        };
    } else {
        userQuery = {
        "to" : globalFdsRefEmail,
        "subject" : `FDS Referral for [Customer Name]@[Account Name] RE: [SF Case Number] - [SF Case Subject]`,
        "body" : `
PRODUCT: [Product Name]
CUSTOMER: [Customer Name] - [Customer URL]
ACCOUNT: [Account Name] - [Account URL]
SF CASE: [SF Case Number] - [SF Case Subject] - [SF Case URL]
SEVERITY: [Case Severity]
FDS INVOLVED: [FDS Name and Version]
FDS ERROR: [Clear description of the issue and steps to reproduce]
`
        };
    }
    let outlookURL = "https://outlook.office.com/mail/deeplink/compose";
    let finalQuery = [];
    Object.entries(userQuery).forEach(([key, value]) => {
        finalQuery.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
    });
    let finalURL = outlookURL + (finalQuery.length ? '?' + finalQuery.join('&') : '');
    window.open(finalURL, 'FDS Referral', 'width=1600,height=900');
}

function consRef() {
    createMFMenu('consRef', 'fa-paper-plane', 'Consulting Referral');
    let mfButtonNew = document.querySelector('#oneHeader').querySelector('.consRef');
    mfButtonNew.addEventListener('click', consRefEvent, false);
}

function consRefEvent() {
    consRefEmail();
}

function consRefEmail() {
    let caseURL;
    let caseNumber;
    let caseSubject;
    let caseContact;
    let caseContactURL;
    let caseAccount;
    let caseAccountURL;
    let caseSeverity;
    let caseProduct;
    let userQuery;
    let caseCheck = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab');
    if (caseCheck) {
        caseNumber = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Case Number"] [name="outputField"]').innerText;
        caseSubject = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Subject"] [name="outputField"]').innerText;
        caseContact = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Contact Name"] [name="outputField"] a').innerText;
        caseContactURL = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Contact Name"] [name="outputField"] a').href;
        caseAccount = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Account Name"] [name="outputField"] a').innerText;
        caseAccountURL = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Account Name"] [name="outputField"] a').href;
        caseSeverity = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Severity"] [name="outputField"]').innerText;
        caseProduct = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Product"] [name="outputField"] a').innerText;
        caseURL = document.querySelector('a.tabHeader[aria-selected="true"]').href;
    }
    if ((caseNumber) && (caseSubject) && (caseContact) && (caseAccount) && (caseURL) && (caseProduct)) {
        userQuery = {
        "to" : "[ACCOUNT MANAGER]",
        "subject" : `Consulting Referral for ${caseContact}@${caseAccount} RE: ${caseNumber} - ${caseSubject}`,
        "body" : `
PRODUCT: ${caseProduct}
CUSTOMER: ${caseContact} - ${caseContactURL}
ACCOUNT: ${caseAccount} - ${caseAccountURL}
SF CASE: ${caseNumber} - ${caseSubject} - ${caseURL}
SEVERITY: ${caseSeverity}
QUESTION OR ISSUE: [Detailed description of the question or issue encountered and steps to reproduce]
REQUIRED FILES: [Links to relevant files, such as diagnostic collections, data files, JCL, logs, screenshots, or other supporting materials]
`
        };
    } else {
        userQuery = {
        "to" : "",
        "subject" : `Consulting Referral for [Customer Name]@[Account Name] RE: [SF Case Number] - [SF Case Subject]`,
        "body" : `
PRODUCT: [Product Name]
CUSTOMER: [Customer Name] - [Customer URL]
ACCOUNT: [Account Name] - [Account URL]
SF CASE: [SF Case Number] - [SF Case Subject] - [SF Case URL]
SEVERITY: [Case Severity]
QUESTION OR ISSUE: [Detailed description of the question or issue encountered and steps to reproduce]
REQUIRED FILES: [Links to relevant files, such as diagnostic collections, data files, JCL, logs, screenshots, or other supporting materials]
`
        };
    }
    let outlookURL = "https://outlook.office.com/mail/deeplink/compose";
    let finalQuery = [];
    Object.entries(userQuery).forEach(([key, value]) => {
        finalQuery.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
    });
    let finalURL = outlookURL + (finalQuery.length ? '?' + finalQuery.join('&') : '');
    window.open(finalURL, 'Consulting Referral', 'width=1600,height=900');
}

function addReminder() {
    createMFMenu('mfreminder', 'fa-calendar', 'Add Reminder');
    let mfButtonNew = document.querySelector('#oneHeader').querySelector('.mfreminder');
    mfButtonNew.addEventListener('click', addReminderEvent, false);
}

function addReminderEvent() {
    let querySubject;
    let caseURL;
    let caseLink;
    let caseNumber;
    let caseSubject;
    let today = new Date();
    let future = today.setDate(today.getDate() + 3);
    let reminderDate = new Date(future).toJSON();
    let caseCheck = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab');
    if (caseCheck) {
        caseNumber = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Case Number"] [name="outputField"]').innerText;
        caseSubject = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Subject"] [name="outputField"]').innerText;
    }
    if ((caseNumber) && (caseSubject)) {
        querySubject = caseNumber + " - " + caseSubject;
        caseURL = document.querySelector('a.tabHeader[aria-selected="true"]').href;
        caseLink = `<a title="${caseNumber}" href="${caseURL}">${querySubject}</a>`;
    } else {
        if ((caseNumber) && !(caseSubject)) {
            querySubject = caseNumber;
            caseURL = document.querySelector('a.tabHeader[aria-selected="true"]').href;
            caseLink = `<a title="${caseNumber}" href="${caseURL}">${querySubject}</a>`;
        } else {
            querySubject = "";
            caseLink = "";
        }
    }
    let userQuery = {
        "rru" : "addevent",
        "startdt" : reminderDate,
        "subject" : querySubject,
        "body" : caseLink
    };
    let calendarURL = "https://outlook.office.com/calendar/deeplink/compose";
    let finalQuery = [];
    Object.entries(userQuery).forEach(([key, value]) => {
        finalQuery.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
    });
    let finalURL = calendarURL + (finalQuery.length ? '?' + finalQuery.join('&') : '');
    window.open(finalURL, 'Add Reminder', 'width=1200,height=700');
}

function mfPP() {
    createMFMenu('mfpp', 'fa-circle-plus', 'Huddle');
    let mfButtonNew = document.querySelector('#oneHeader').querySelector('.mfpp');
    mfButtonNew.addEventListener('click', mfPPEvent, false);
}

function mfPPEvent() {
    window.open(globalPP, '_blank');
}

function mfEDU() {
    createMFMenu('mfedu', 'fa-book-open-reader', 'Education System');
    let mfButtonNew = document.querySelector('#oneHeader').querySelector('.mfedu');
    mfButtonNew.addEventListener('click', mfEDUEvent, false);
}

function mfEDUEvent() {
    window.open(globalEDU, '_blank');
}

function customURLs() {
    try {
        let URLS = JSON.parse(globalURLS);
        let countURLs = 1;
        Object.entries(URLS).forEach(([key, value]) => {
            let urlClass = `custom${countURLs}`;
            createMFMenu(urlClass, 'fa-bolt', key);
            let urlElement = document.getElementsByClassName(urlClass);
            urlElement[0].addEventListener('click', function(){window.open(value, '_blank');}, false);
            countURLs = countURLs + 1;
        });
    } catch (err) {
        window.alert("Custom URL list JSON format is not correct!");
    }
}

function updateCustomURLs() {
    let removeURL = document.querySelectorAll('.fa-bolt');
    for (let i = 0; i < removeURL.length; ++i) {
        removeURL[i].parentNode.remove();
    }
    customURLs();
}

function initQMonitor() {
    if (!globalQueue) return;
    let caseQueue = queryShadowRoot(activeQueueContains('span', `${globalQueue}`)[0]?.closest('lst-common-list-internal'), '.slds-grid.listDisplays')?.[0];
    let caseTable = queryShadowRoot(caseQueue, 'tbody tr');
    if ( (caseQueue) && (caseTable) ) {
        caseTable.forEach(caseRow => {
            let caseNumber = caseRow.querySelector('th').innerText;
            oldCaseArray.push(caseNumber);
        });
        qMonitor();
    } else if (caseQueue) {
        qMonitor();
    } else {
        let handled = false;
        let observer = new MutationObserver(mutations => {
            if (handled) return;
            setTimeout(function() {
                let caseQueue = queryShadowRoot(activeQueueContains('span', `${globalQueue}`)[0]?.closest('lst-common-list-internal'), '.slds-grid.listDisplays')?.[0];
                if (!caseQueue) return;
                handled = true;
                observer.disconnect();
                let caseTable = queryShadowRoot(caseQueue, 'tbody tr');
                if ( (caseQueue) && (caseTable) ) {
                    caseTable.forEach(caseRow => {
                        let caseNumber = caseRow.querySelector('th').innerText;
                        oldCaseArray.push(caseNumber);
                    });
                }
                qMonitor();
            }, 5000);
        });
        observer.observe(document.body, {childList: true, subtree: true});
    }
}

function qMonitor() {
    QMonActive();
    let caseQueue = queryShadowRoot(activeQueueContains('span', `${globalQueue}`)[0]?.closest('lst-common-list-internal'), '.slds-grid.listDisplays')?.[0];
    if (!caseQueue) return;
    qObserver = new MutationObserver(mutations => {
        let currentQueue = queryShadowRoot(activeQueueContains('span', `${globalQueue}`)[0]?.closest('lst-common-list-internal'), '.slds-grid.listDisplays')?.[0];
        if (currentQueue) {
            setTimeout(function() {
                qNotify();
            }, 2000);
        }
    });
    qObserver.observe(caseQueue, {childList: true, subtree: true});
}

function qNotify() {
    let caseQueue = queryShadowRoot(activeQueueContains('span', `${globalQueue}`)[0]?.closest('lst-common-list-internal'), '.slds-grid.listDisplays')?.[0];
    let caseTable = queryShadowRoot(caseQueue, 'tbody tr');
    if (caseTable) {
        caseTable.forEach(caseRow => {
            let caseNumber = caseRow.querySelector('th').innerText;
            let caseSubjectOuter = caseRow.querySelector('[data-label="Subject"]');
            let caseSubject =  queryShadowRoot(caseSubjectOuter, 'a')[0].innerText;
            let caseURL = 'https://rocketsoftware.lightning.force.com/lightning/r/' + caseRow.getAttribute('data-row-key-value') + '/view';
            let notifyBody;
            if ( !(caseSubject) ) {
                notifyBody = caseNumber;
            } else {
                notifyBody = caseNumber + ' - ' + caseSubject;
            }
            if (oldCaseArray.indexOf(caseNumber) == -1) {
                if (globalQNotify) {
                    (async() => {
                        if (!window.Notification) {
                            console.log('Browser does not support notifications.');
                        } else {
                            if (Notification.permission === 'granted') {
                                const qNotification = new Notification('SFExtension Queue Monitor', {
                                    body: notifyBody,
                                    icon: iconURL
                                });
                                qNotification.addEventListener('click', () => {
                                    window.open(caseURL, '_blank');
                                });
                            } else {
                                Notification.requestPermission()
                                    .then(function(p) {
                                        if (p === 'granted') {
                                            const qNotification = new Notification('SFExtension Queue Monitor', {
                                                body: notifyBody,
                                                icon: iconURL
                                            });
                                            qNotification.addEventListener('click', () => {
                                                window.open(caseURL, '_blank');
                                            });
                                        } else {
                                            console.log('User blocked notifications.');
                                        }
                                    })
                                    .catch(function(err) {
                                        console.error(err);
                                    });
                            }
                        }
                    })();
                    if (globalQNotifyWeb) {
                        chrome.runtime.sendMessage({
                            action: "newCase",
                            url: globalWebhook,
                            content: notifyBody + ' ' + caseURL
                        });
                    }
                }
            }
            newCaseArray.push(caseNumber);
        });
        if ( (caseQueue) && (caseTable) ) {
            oldCaseArray = [];
            oldCaseArray = newCaseArray;
            newCaseArray = [];
        }
    } else {
        if ( (caseQueue) && !(caseTable) ) {
            setTimeout(function() {
                emptyArrays();
            }, 2000);
        }
    }
}

function emptyArrays() {
    let caseQueue = queryShadowRoot(activeQueueContains('span', `${globalQueue}`)[0]?.closest('lst-common-list-internal'), '.slds-grid.listDisplays')?.[0];
    let caseTable = queryShadowRoot(caseQueue, 'tbody tr');
    if ( (caseQueue) && !(caseTable) ) {
        oldCaseArray = [];
        newCaseArray = [];
    }
}

function addCopyButton() {
    let observer = new MutationObserver(mutations => {
        let activeTab = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab');
        if (activeTab) {
            let caseButtonCheck = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('.highlights-icon-container.slds-avatar.slds-m-right_small.icon.copyButton');
            if (caseButtonCheck === null) {
                let field  = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('.highlights-icon-container.slds-avatar.slds-m-right_small.icon');
                (async ()=>{
                    if (field) {
                        field.className = 'highlights-icon-container slds-avatar slds-m-right_small icon copyButton';
                        field.style.cursor = 'pointer';
                        let fieldTitle = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('.highlights-icon-container.slds-avatar.slds-m-right_small.icon > img');
                        fieldTitle.title = 'Copy Case Number & Subject';
                        field.addEventListener('click', async () => {
                            let caseNumber = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Case Number"] [name="outputField"]');
                            let caseSubject  = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Subject"] [name="outputField"]');
                            let selectedText = caseNumber.innerText + ' - ' + caseSubject.innerText;
                            let caseURL = document.querySelector('a.tabHeader[aria-selected="true"]').href;
                            const clipboardItem = new ClipboardItem({
                                "text/plain": new Blob(
                                    [selectedText],
                                    { type: "text/plain" }
                                ),
                                "text/html": new Blob(
                                    [`<a href="${caseURL}">${selectedText}</a>`],
                                    { type: "text/html" }
                                ),
                            });
                            await navigator.clipboard.write([clipboardItem]);
                        });
                    }
                    await sleep(500);
                })();
            }
        }
    });
    let splitRight = document.querySelector('div.split-right');
    if (splitRight) {
        observer.observe(splitRight, {childList: true, subtree: true});
    } else {
        let bodyObserver = new MutationObserver(() => {
            let target = document.querySelector('div.split-right');
            if (target) {
                bodyObserver.disconnect();
                observer.observe(target, {childList: true, subtree: true});
            }
        });
        bodyObserver.observe(document.body, {childList: true, subtree: true});
    }
}

function addCaseTitle() {
    let observer = new MutationObserver(mutations => {
        let activeCase = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab');
        if (activeCase) {
            let headerTitle = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('h1');
            if (headerTitle) {
                let caseNumber = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Case Number"] [name="outputField"]')?.innerText;
                let caseSubject = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('[field-label="Subject"] [name="outputField"]')?.innerText;
                let oldSubject = headerTitle.querySelector('[name="primaryField"]')?.innerText;
                let tempSubject = oldSubject?.replace(`${caseNumber} - `, '');
                if ((tempSubject != caseSubject) && (caseNumber && caseSubject)) {
                    headerTitle.querySelector('[name="primaryField"]').innerText = caseNumber + ' - ' + caseSubject;
                }
            }
        } 
        (async ()=>{
            observer.disconnect();
            await sleep(1000);
            let reconnectTarget = document.querySelector('div.split-right');
            if (reconnectTarget) observer.observe(reconnectTarget, {childList: true, subtree: true});
        })();
    });
    let splitRight = document.querySelector('div.split-right');
    if (splitRight) {
        observer.observe(splitRight, {childList: true, subtree: true});
    } else {
        let bodyObserver = new MutationObserver(() => {
            let target = document.querySelector('div.split-right');
            if (target) {
                bodyObserver.disconnect();
                observer.observe(target, {childList: true, subtree: true});
            }
        });
        bodyObserver.observe(document.body, {childList: true, subtree: true});
    }
}

function KCSURL() {
    let observer = new MutationObserver(mutations => {
        let headerCell = document.querySelector('[title="URL Name"]');
        if (headerCell) {
            let headerCellIndex = headerCell.cellIndex;
            let KCSRows = document.querySelectorAll("tbody tr:not([title='KCSURL'])");
            KCSRows.forEach(row => {
                let KCSCell = row.cells[headerCellIndex];
                let KCSURL = KCSCell?.innerText;
                if (KCSURL) {
                    let finalURL = `<span class="slds-grid slds-grid--align-spread"><a class="slds-truncate slds-truncate" target="_blank" href="https://my.rocketsoftware.com/RocketCommunity/s/article/${KCSURL}">${KCSURL}</a></span>`;
                    KCSCell.innerHTML = finalURL;
                    row.title = "KCSURL";
                }
            });
        }
        let ActiveURLField = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab');
        if (ActiveURLField) {
            let URLField = ActiveURLField.querySelector('[field-label="URL Name"] lightning-formatted-text');
            if (URLField) {
                let KCSCheck = URLField?.querySelector("a");
                if (URLField && !KCSCheck) {
                    let KCSURL = URLField.innerText;
                    let finalURL = `<a target="_blank" href="https://my.rocketsoftware.com/RocketCommunity/s/article/${KCSURL}">${KCSURL}</a>`;
                    URLField.innerHTML = finalURL;
                }
            }
        }       
    });
    let splitRight = document.querySelector('div.split-right');
    if (splitRight) {
        observer.observe(splitRight, {childList: true, subtree: true});
    } else {
        let bodyObserver = new MutationObserver(() => {
            let target = document.querySelector('div.split-right');
            if (target) {
                bodyObserver.disconnect();
                observer.observe(target, {childList: true, subtree: true});
            }
        });
        bodyObserver.observe(document.body, {childList: true, subtree: true});
    }
}

function fullWidthCase() {
    let observer = new MutationObserver(mutations => {
        let caseView = document.querySelector('div.split-right')?.querySelector('div.template-workspace-contents.slds-grid');
        if (caseView && globalWide) {
            caseView.classList.remove("slds-grid");
        }
    });
    let splitRight = document.querySelector('div.split-right');
    if (splitRight) {
        observer.observe(splitRight, {childList: true, subtree: true});
    } else {
        let bodyObserver = new MutationObserver(() => {
            let target = document.querySelector('div.split-right');
            if (target) {
                bodyObserver.disconnect();
                observer.observe(target, {childList: true, subtree: true});
            }
        });
        bodyObserver.observe(document.body, {childList: true, subtree: true});
    }
}

function signatureButton() {
    let observer = new MutationObserver(mutations => {
        let mfSigCheck = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab')?.querySelector('.mfSig');
        if (!mfSigCheck) {
            let buttons = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab')?.querySelector('.publisherInputContainer [aria-label="Insert content"]');
            if (buttons) {
                let sigButton = document.createElement('li');
                sigButton.addEventListener('click', sigEvent, false);
                sigButton.innerHTML = `<button class="slds-button slds-button_icon slds-button_icon-border-filled fa-solid fa-signature mfSig" title="Insert Signature" aria-label="Insert Signature">`;
                buttons.appendChild(sigButton);
            }
        }
    });
    let splitRight = document.querySelector('div.split-right');
    if (splitRight) {
        observer.observe(splitRight, {childList: true, subtree: true});
    } else {
        let bodyObserver = new MutationObserver(() => {
            let target = document.querySelector('div.split-right');
            if (target) {
                bodyObserver.disconnect();
                observer.observe(target, {childList: true, subtree: true});
            }
        });
        bodyObserver.observe(document.body, {childList: true, subtree: true});
    }
}

function sigEvent() {
    let originalHTML = document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('.ql-editor').innerHTML;
    document.querySelector('div.split-right > .tabContent.active.oneConsoleTab').querySelector('.ql-editor').innerHTML = originalHTML + convertSigToHTML(globalSig);
    document.querySelector('div.split-right > .tabContent.active.oneConsoleTab')?.querySelector('.publisherVisibilityValue span')?.click();
    document.querySelector('div.split-right > .tabContent.active.oneConsoleTab')?.querySelector('[title="All with access"]')?.click();
}

function convertSigToHTML(input) {
  let lines = input.split('\n').map(line => line.trim());
  let html = '<p><br></p>';
  lines.forEach(line => {
    if (line !== '') {
        html += `<p>${line}<br></p>`;
    }
  });
  html = html.replace(/<p>([^<]*)<br><\/p>$/, '<p>$1</p>');
  return html;
}

function resolutionTitle() {
    let observer = new MutationObserver(mutations => {
        let container = document.querySelector('#split-left');
        let resTable = queryShadowRoot(container, '[data-label="Resolution Summary"]');
        if (resTable) {
            resTable.forEach(el => {
                if (!el.title) {
                    el.title = el.innerText;
                }
            });
        }
    });
    let splitLeft = document.querySelector('#split-left');
    if (splitLeft) {
        observer.observe(splitLeft, {childList: true, subtree: true});
    } else {
        let bodyObserver = new MutationObserver(() => {
            let target = document.querySelector('#split-left');
            if (target) {
                bodyObserver.disconnect();
                observer.observe(target, {childList: true, subtree: true});
            }
        });
        bodyObserver.observe(document.body, {childList: true, subtree: true});
    }
}

function extLoaded() {
    let observer = new MutationObserver(mutations => {
        let initial = document.querySelector('.oneUtilityBar');
        let extLoadedCheck = document.querySelector('.ExtLoaded');
        if ((initial) && (!extLoadedCheck)) {
            let footer = initial.querySelector('.utilitybar');
            if (footer) {
                let footera = document.createElement("a");
                footera.className = "ExtLoaded";
                footera.innerText = `SFExt ${installedVersion}`;
                footera.href = configURL;
                footera.setAttribute('target', '_blank');
                footer.appendChild(footera);
                observer.disconnect();
            }
        }
    });
    observer.observe(document.body, {childList: true, subtree: true});
}

function QMonActive() {
    let initial = document.querySelector('.oneUtilityBar');
    let QMonActiveCheck = document.querySelector('.QMonActive');
    if (QMonActiveCheck) {
        QMonActiveCheck.remove();
    }
    if (initial) {
        let footer = initial.querySelector('.utilitybar');
        if (footer) {
            let footera = document.createElement("h4");
            footera.className = "QMonActive";
            footera.innerText = `SFExt Queue Monitor is active for queue: ${globalQueue}`;
            footer.appendChild(footera);
        }
    }
}

function dailyUsers() {
    chrome.runtime.sendMessage({
        action: "dailyUsers"
    });
}

function keepAlive() {
    chrome.runtime.sendMessage({
        action: "keepAlive"
    });
}

function moveMouse(){
	var evt = new MouseEvent("mousemove", {
        view: window,
        bubbles: true,
        cancelable: true
    });
    document.dispatchEvent(evt);
}

function fixMouse() {
    document.addEventListener('mouseup', e => {
        if (typeof e === 'object' && [3, 4].includes(e.button)) {
            e.preventDefault();
        }
    });
}

function EE() {
    window.addEventListener('keydown', function(event) {
        if (event.ctrlKey && event.shiftKey && event.code === 'F1') {
            if (intervalID) {
                clearInterval(intervalID);
            }
            let img = document.createElement('img');
            img.src = 'https://i.giphy.com/12FOQ3mPLElLHy.webp';
            img.style.position = 'absolute';
            img.style.zIndex = 9999;
            img.style.width = '125px';
            document.body.appendChild(img);
            let elements = document.querySelectorAll("*");
            elements.forEach(function(element) {
                element.classList.add("explode");
            });
            let x = 200;
            let y = 200;
            let dx = 1;
            let dy = 1;
            setInterval(function() {
                x += dx;
                y += dy;
                if (x >= window.innerWidth - 150 || x <= 0) dx = -dx;
                if (y >= window.innerHeight - 150 || y <= 0) dy = -dy;
                img.style.top = y + 'px';
                img.style.left = x + 'px';
                img.style.transform = dx > 0 ? 'scaleX(1)' : 'scaleX(-1)';
                let elements = document.querySelectorAll('table.slds-table *');
                if ( (elements.length < 10) ) {
                    return;
                }
                let randomIndex = Math.floor(Math.random() * elements.length);
                let element = elements[randomIndex];
                let explosion = document.createElement("img");
                explosion.src = "https://i.gifer.com/origin/d7/d7ac4f38b77abe73165d85edf2cbdb9e_w200.gif";
                explosion.classList.add("explosion-graphic");
                explosion.style.zIndex = 9998;
                if (element) {
                    element.style.display = "none";
                    let parentExplosion = element.parentNode;
                    if (element.class != "explosion-graphic") {
                        parentExplosion.appendChild(explosion);
                    }
                }
            }, 1);
        }
    });
}

function updateCheck() {
    chrome.runtime.sendMessage({
        action: "updateCheck"
    }, function(response) {
        let latestVersion = response.latestVer;
        if (latestVersion) {
            let newVersion = compareVersions(installedVersion, latestVersion.toString());
            if ( (newVersion == 1) ) {
                const updateURL = `https://github.com/UNiXMIT/UNiXSF/raw/main/updates/Chromium/${latestVersion}/SFExt-${latestVersion}.zip`;
                // (async() => {
                //     let updateMessage = `Version ${latestVersion}`;
                //     if (!window.Notification) {
                //         console.log('Browser does not support notifications.');
                //     } else {
                //         if (Notification.permission === 'granted') {
                //             const UpdateNofity = new Notification('SFExtension Update Available', {
                //                 body: updateMessage,
                //                 icon: iconURL
                //             });
                //             UpdateNofity.addEventListener('click', () => {
                //                 window.open(updateURL, '_blank');
                //             });
                //         } else {
                //             Notification.requestPermission()
                //                 .then(function(p) {
                //                     if (p === 'granted') {
                //                         const UpdateNofity = new Notification('SFExtension Update Available', {
                //                             body: updateMessage,
                //                             icon: iconURL
                //                         });
                //                         UpdateNofity.addEventListener('click', () => {
                //                             window.open(updateURL, '_blank');
                //                         });
                //                     } else {
                //                         console.log('User blocked notifications.');
                //                     }
                //                 })
                //                 .catch(function(err) {
                //                     console.error(err);
                //                 });
                //         }
                //     }
                // })();
                if ( !(initDropDown) ) {
                    let ul = document.querySelector('.mflist');
                    let li = ul.appendChild(document.createElement('li'));
                    li.classList.add('mfupdate');
                    let fa = li.appendChild(document.createElement('i'));
                    fa.classList.add('fa-solid', 'fa-xl');
                    fa.classList.add('fa-arrows-rotate');
                    fa.classList.add('fa-spin');
                    li.appendChild(document.createTextNode(`SFExt Update ${latestVersion}`));
                    let mfButtonNew = document.querySelector('#oneHeader').querySelector('.mfupdate');
                    mfButtonNew.addEventListener('click', () => {window.open(updateURL, '_blank');});
                }
            }
        }
    });
}

function compareVersions(v1, v2) {
    const v1Parts = v1.split('.');
    const v2Parts = v2.split('.');
    for (let i = 0; i < v1Parts.length || i < v2Parts.length; i++) {
        if (i >= v1Parts.length) {
            return 1;
        } else if (i >= v2Parts.length) {
            return -1;
        }
        if (parseInt(v1Parts[i]) > parseInt(v2Parts[i])) {
            return -1;
        } else if (parseInt(v1Parts[i]) < parseInt(v2Parts[i])) {
            return 1;
        }
    }
    return 0;
}  

const sleep = (milliseconds) => {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
};

// (async ()=>{
//     console.log('foo');
//     await sleep(2000);
//     console.log('bar');
// })();

function contains(selector, text) {
    let elements = document.querySelectorAll(selector);
    return Array.prototype.filter.call(elements, function(element){
      return RegExp(text).test(element.innerText);
    });
}

function activeQueueContains(selector, text) {
    let activeQueue = document.querySelector('#split-left');
    if (activeQueue) {
        let elements = activeQueue.querySelectorAll(selector);
        return Array.prototype.filter.call(elements, function(element){
        return RegExp(text).test(element.innerText);
        });
    } else {
        return[];
    }
}

// Example usage:
// contains('div', 'sometext');     find "div" that contain "sometext"
// contains('div', /^sometext/);    find "div" that start with "sometext"
// contains('div', /sometext$/i);   find "div" that end with "sometext", case-insensitive

function queryShadowRoot(root, selector) {
    const results = [];
    const seen = new Set();
    const stack = [root];
    while (stack.length) {
        const element = stack.pop();
        if (!element || seen.has(element)) continue;
        seen.add(element);
        if (element.matches?.(selector)) {
            results.push(element);
        }
        if (element.shadowRoot) {
            stack.push(...element.shadowRoot.children);
        }
        if (element.children?.length) {
            stack.push(...element.children);
        }
    }
    return results;
}

// Example usage:
// const container = document.querySelector('#my-container'); // your starting element
// const allMatches = queryShadowRoot(container, '.target-class');
// console.log(allMatches);

initSyncData();
let initInterval = setInterval(function() {
    if (globalInit) {
        clearInterval(initInterval);
        getSyncData();
        queueRefresh();
        mfNav();
        setTimeout(function() {
            initQMonitor();
            setInterval(function() {
                let caseQueue = queryShadowRoot(activeQueueContains('span', `${globalQueue}`)[0]?.closest('lst-common-list-internal'), '.slds-grid.listDisplays')?.[0];
                if (caseQueue && qObserver) {
                    qObserver.disconnect();
                    oldCaseArray = [];
                    newCaseArray = [];
                    initQMonitor();
                }
            }, 5 * 60 * 1000);
        }, 10000);
        setTimeout(function() {
            addCopyButton();
            addCaseTitle();
            KCSURL();
            fullWidthCase();
            signatureButton();
            resolutionTitle();
            extLoaded();
            dailyUsers();
            setInterval(keepAlive, 30000);
            setInterval(moveMouse, 60000);
            fixMouse();
            EE();
        }, 2000);
        setTimeout(function() {
            updateCheck();
        }, 20000);
    }
}, 500);