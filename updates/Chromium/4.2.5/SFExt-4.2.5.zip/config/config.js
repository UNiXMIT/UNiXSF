const installedVersion = chrome.runtime.getManifest().version;
const configURL = chrome.runtime.getURL('config.html');
const themeStorageKey = 'savedTheme';

function applyTheme(theme) {
  const normalizedTheme = theme === 'light' ? 'light' : 'dark';
  document.body.classList.toggle('light-theme', normalizedTheme === 'light');
  const themeToggle = document.getElementById('themeToggle');
  const themeIcon = document.getElementById('themeIcon');
  if (themeToggle) {
    const nextThemeLabel = normalizedTheme === 'light' ? 'dark' : 'light';
    themeToggle.setAttribute('aria-label', `Switch to ${nextThemeLabel} mode`);
    themeToggle.setAttribute('title', `Switch to ${nextThemeLabel} mode`);
    themeToggle.setAttribute('aria-pressed', normalizedTheme === 'light' ? 'true' : 'false');
  }
  if (themeIcon) {
    themeIcon.className = normalizedTheme === 'light' ? 'fa-solid fa-moon' : 'fa-solid fa-sun';
  }
  return normalizedTheme;
}

function toggleTheme() {
  const nextTheme = document.body.classList.contains('light-theme') ? 'dark' : 'light';
  applyTheme(nextTheme);
  chrome.storage.sync.set({
    [themeStorageKey]: nextTheme
  });
}

function simpleFormatToJSON(simpleText) {
  const lines = simpleText.trim().split('\n').filter(line => line.trim());
  const urlsObj = {};
  lines.forEach(line => {
    const match = line.match(/^(.+?):\s*(.+)$/);
    if (match) {
      const name = match[1].trim();
      const url = match[2].trim();
      if (name && url) {
        urlsObj[name] = url;
      }
    }
  });
  return JSON.stringify(urlsObj);
}

function jsonToSimpleFormat(jsonText) {
  try {
    const urlsObj = JSON.parse(jsonText);
    const lines = [];
    Object.entries(urlsObj).forEach(([name, url]) => {
      lines.push(`${name}: ${url}`);
    });
    return lines.join('\n');
  } catch (e) {
    return '';
  }
}

function save_options() {
  let refreshTimeout = document.getElementById('timeout').value;
  let defect = document.getElementById('defect').value;
  let pp = document.getElementById('pp').value;
  let edu = document.getElementById('edu').value;
  let queue = document.getElementById('queue').value;
  let qnotify = document.getElementById('qnotify').checked;
  let qnotifyweb = document.getElementById('qnotifyweb').checked;
  let webhook = document.getElementById('webhook').value;
  let refEmail = document.getElementById('refemail').value;
  let fdsRefEmail = document.getElementById('fdsrefemail').value;
  let signature = document.getElementById('signature').value;
  let customurls = document.getElementById('customurls').value;
  let grabLink = document.getElementById('grabLink').checked;
  let wideCase = document.getElementById('wideCase').checked;
  const customurlsJSON = simpleFormatToJSON(customurls);
  const currentTheme = document.body.classList.contains('light-theme') ? 'light' : 'dark';

  chrome.storage.sync.set({
      savedTimeout: refreshTimeout,
      savedDefect: defect,
      savedPP: pp,
      savedEDU: edu,
      savedQueue: queue,
      savedQNotify: qnotify,
      savedQNotifyWeb: qnotifyweb,
      savedWebhook: webhook,
      savedRefEmail: refEmail,
      savedFdsRefEmail: fdsRefEmail,
      savedSig: signature,
      savedGrab: grabLink,
        savedWide: wideCase,
        [themeStorageKey]: currentTheme
  }, function() {
      let status = document.getElementById('status');
      status.textContent = 'Options Saved';
      setTimeout(function() {
          status.textContent = '';
      }, 750);
  });
}

function reset_options() {
  chrome.storage.sync.remove(["savedTimeout", "savedDefect", "savedPP", "savedEDU", "savedQueue", "savedQNotify", "savedQNotifyWeb", "savedWebhook", "savedRefEmail", "savedFdsRefEmail", "savedSig", "savedURLS", "savedGrab", "savedWide", themeStorageKey], function() {
      let error = chrome.runtime.lastError;
      if (error) {
          console.error(error);
      }
  });
  window.location.reload();
}

function restore_options() {
  chrome.storage.sync.get({
      savedTimeout: 60,
      savedDefect: '',
      savedPP: '',
      savedEDU: '',
      savedQueue: 'NOTIFY',
      savedQNotify: false,
      savedQNotifyWeb: false,
      savedWebhook: '',
      savedRefEmail: '',
      savedFdsRefEmail: '',
      savedSig: '',
      savedURLS: `{"SFExt":"${configURL}"}`,
      savedUUID: '',
      savedGrab: false,
        savedWide: false,
        savedTheme: 'dark'
  }, function(result) {
        applyTheme(result.savedTheme);
      document.getElementById('timeout').value = result.savedTimeout;
      document.getElementById('defect').value = result.savedDefect;
      document.getElementById('pp').value = result.savedPP;
      document.getElementById('edu').value = result.savedEDU;
      document.getElementById('queue').value = result.savedQueue;
      document.getElementById('qnotify').checked = result.savedQNotify;
      document.getElementById('qnotifyweb').checked = result.savedQNotifyWeb;
      document.getElementById('webhook').value = result.savedWebhook;
      document.getElementById('refemail').value = result.savedRefEmail;
      document.getElementById('fdsrefemail').value = result.savedFdsRefEmail;
      document.getElementById('signature').value = result.savedSig;
      document.getElementById('customurls').value = jsonToSimpleFormat(result.savedURLS);
      document.getElementById('grabLink').checked = result.savedGrab;
      document.getElementById('wideCase').checked = result.savedWide;
      if (!result.savedUUID) {
        let globalUUID = crypto.randomUUID();
        chrome.storage.sync.set({
        savedUUID: globalUUID
        });
      }
      document.getElementById('uuid').textContent = result.savedUUID;
  });
}

function export_options() {
    chrome.storage.sync.get({
        savedTimeout: 60,
        savedDefect: '',
        savedPP: '',
        savedEDU: '',
        savedQueue: 'NOTIFY',
        savedQNotify: false,
        savedQNotifyWeb: false,
        savedWebhook: '',
        savedRefEmail: '',
        savedFdsRefEmail: '',
        savedSig: '',
        savedURLS: `{"SFExt":"${configURL}"}`,
        savedUUID: '',
        savedGrab: false,
        savedWide: false,
        savedTheme: 'dark'
    }, function(result) {
        chrome.downloads.onChanged.addListener(function(downloadDelta) {
            if (downloadDelta.state && downloadDelta.state.current === "complete") {
                let status = document.getElementById('status');
                status.textContent = 'Options Exported';
                setTimeout(function() {
                    status.textContent = '';
                }, 750);
            } else {
                if (downloadDelta.state && downloadDelta.state.current === "interrupted") {
                    let status = document.getElementById('status');
                    status.textContent = 'Export Failed!';
                    setTimeout(function() {
                        status.textContent = '';
                    }, 750);
                }
            }
        });
        let items = JSON.stringify(result, null, 2);
        let url = 'data:application/json;base64,' + btoa(items);
        chrome.downloads.download({
            url: url,
            filename: 'sfext.json',
            saveAs: true 
        }); 
    });
}

function import_options() {    
    const fileInput = document.createElement("input");
    fileInput.type = "file";
    fileInput.addEventListener("change", (event) => {
      const file = event.target.files[0];
      const reader = new FileReader();
      reader.addEventListener("load", (event) => {
        const contents = event.target.result;
        const json = JSON.parse(contents);
        chrome.storage.sync.set({
            savedTimeout: json.savedTimeout,
            savedDefect: json.savedDefect,
            savedPP: json.savedPP,
            savedEDU: json.savedEDU,
            savedQueue: json.savedQueue,
            savedQNotify: json.savedQNotify,
            savedQNotifyWeb: json.savedQNotifyWeb,
            savedWebhook: json.savedWebhook,
            savedRefEmail: json.savedRefEmail,
            savedFdsRefEmail: json.savedFdsRefEmail,
            savedSig: json.savedSig,
            savedURLS: json.savedURLS,
            savedUUID: json.savedUUID,
            savedGrab: json.savedGrab,
            savedWide: json.wideCase,
            savedTheme: json.savedTheme || 'dark'
        }, function() {
            try {
                let status = document.getElementById('status');
                status.textContent = 'Options Imported';
                setTimeout(function() {
                    status.textContent = '';
                    window.location.reload();
                }, 750);
            } catch (error) {
                let status = document.getElementById('status');
                status.textContent = 'Import Failed!';
                setTimeout(function() {
                    status.textContent = '';
                    window.location.reload();
                }, 750);
            }
        }) 
      });
      reader.readAsText(file);
    });
    fileInput.click();
}

document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById('save').addEventListener('click', save_options);
document.getElementById('reset').addEventListener('click', reset_options);
document.getElementById('export').addEventListener('click', export_options);
document.getElementById('import').addEventListener('click', import_options);
document.getElementById('themeToggle').addEventListener('click', toggleTheme);
document.getElementById('version').textContent = installedVersion;